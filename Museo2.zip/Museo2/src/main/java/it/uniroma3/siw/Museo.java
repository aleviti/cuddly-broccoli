
package it.uniroma3.siw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Museo {

	public static void main(String[] args) {
		SpringApplication.run(Museo.class, args);
	}

}
