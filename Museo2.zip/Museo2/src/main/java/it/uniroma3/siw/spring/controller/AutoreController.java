package it.uniroma3.siw.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import it.uniroma3.siw.spring.controller.validator.AutoreValidator;
import it.uniroma3.siw.spring.model.Autore;
import it.uniroma3.siw.spring.service.AutoreService;


@Controller
public class AutoreController {
	@Autowired
	private AutoreService autoreService;

	@Autowired
	private AutoreValidator autoreValidator;
	    
	@RequestMapping(value="/admin/autore", method = RequestMethod.GET)
	public String addAutore(Model model) {
		model.addAttribute("autore", new Autore());
	    return "admin/autoreForm";
	}

	@RequestMapping(value = "/autore/{id}", method = RequestMethod.GET)
	public String getAutore(@PathVariable("id") Long id, Model model) {
		model.addAttribute("autore", this.autoreService.autorePerId(id));
		return "autore";
	}

	@RequestMapping(value = "/autore", method = RequestMethod.GET)
	public String getAutore(Model model) {
			model.addAttribute("autori", this.autoreService.tutti());
			return "autori";
	}

	@RequestMapping(value = "/admin/autore", method = RequestMethod.POST)
	public String addAutore(@ModelAttribute("autore") Autore autore, 
										Model model, BindingResult bindingResult) {
		this.autoreValidator.validate(autore, bindingResult);
	    if (!bindingResult.hasErrors()) {
	    	this.autoreService.inserisci(autore);
	        model.addAttribute("autori", this.autoreService.tutti());
	        return "autori";
	    }
	    return "admin/autoreForm";
	}
	}





