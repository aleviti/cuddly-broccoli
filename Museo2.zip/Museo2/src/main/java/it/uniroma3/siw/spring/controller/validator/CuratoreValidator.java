package it.uniroma3.siw.spring.controller.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import it.uniroma3.siw.spring.model.Curatore;

@Component
public class CuratoreValidator  implements Validator {
	  
    
    
    final  Integer MAX_NAME_LENGTH = 50;
    final  Integer MIN_NAME_LENGTH = 2;
   
   
    
    @Override
    public void validate(Object o, Errors errors){
       Curatore  curatore= (Curatore) o;
            String nomeCuratore = curatore.getNomeCuratore().trim();
            
            
               
             if(nomeCuratore.isEmpty())
                 errors.rejectValue(  "nomeCuratore",  "required");
            else if(nomeCuratore.length() < MIN_NAME_LENGTH || nomeCuratore.length()> MAX_NAME_LENGTH) 
                errors.rejectValue("nomeCuratore", "size");
                
    
            
                
    
               
    
    }
     
    

    @Override
    public boolean supports(Class<?> clazz) {
     return Curatore.class.equals(clazz);
}



}


