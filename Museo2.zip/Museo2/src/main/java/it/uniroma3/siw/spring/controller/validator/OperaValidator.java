package it.uniroma3.siw.spring.controller.validator;


import org.springframework.stereotype.Component;
  import org.springframework.validation.Errors;
  import org.springframework.validation.Validator;

import it.uniroma3.siw.spring.model.Opera;










      @Component
      public class OperaValidator implements Validator {
           
      
          
          
          final  Integer MAX_TITOLO_LENGTH = 50;
          final  Integer MIN_TITOLO_LENGTH = 2;
          
          final  Integer MAX_IMMAGINE_LENGTH = 30;
          final  Integer MIN_IMMAGINE_LENGTH = 1;
          
         
          
          @Override
          public void validate(Object o, Errors errors){
             Opera opera = (Opera) o;
                  String titolo = opera.getTitolo().trim();
                  
                  
                     
                   if(titolo.isEmpty())
                       errors.rejectValue(  "title",  "required");
                  else if(titolo.length() < MIN_TITOLO_LENGTH || titolo.length()> MAX_TITOLO_LENGTH) 
                      errors.rejectValue("title", "size");
          }
      
          @Override
          public boolean supports(Class<?> clazz) {
           return Opera.class.equals(clazz);
          }
      }
