package it.uniroma3.siw.spring.model;







import javax.persistence.*;



@Entity

public class Amministratore {

	@Id
	@GeneratedValue(strategy= GenerationType.AUTO )
	private Long id;
	
	
	
	@Column(nullable = false , length =100)
    private String nome;

    @Column(nullable = false,length =100)
    private String cognome;
	
	
   
    
    public Amministratore () {
		
		
	}
    
    public Amministratore(String nome, String cognome) {
    	this();
    	this.nome = nome;
    	this.cognome = cognome;
    }
   

	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	
  


	
	

	
	 public String getCognome() {
	        return cognome;
	    }

	    public void setCognome(String cognome) {
	        this.cognome = cognome;
	    }

	    public String getNome() {
	        return nome;
	    }

	    public void setNome(String nome) {
	        this.nome = nome;
	    }
	    
	    
	   
	    @Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			
			result = prime * result + ((cognome == null) ? 0 : cognome.hashCode());
			result = prime * result + ((nome == null) ? 0 : nome.hashCode());
			
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Amministratore other = (Amministratore) obj;
			
			if (cognome == null) {
				if (other.cognome != null)
					return false;
			} else if (!cognome.equals(other.cognome))
				return false;
			if (nome == null) {
				if (other.nome != null)
					return false;
			} else if (!nome.equals(other.nome))
				return false;
			return true;
		}

		@Override
		public String toString() {
			return "Amministratore [id=" + id + ", nome=" + nome + ", cognome=" + cognome + "]";
		}

}
