package it.uniroma3.siw.spring.model;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class Artista {
	 @Id
	    @GeneratedValue(strategy = GenerationType.AUTO)
	    private Long id;

	    @Column(nullable = false ,length=20)
	    private String nome;
	    @Column(nullable = false , length=20)
	    private String cognome;
	    @Column(nullable = false, length=10)
	    private String nazionalita;
	    @Column(nullable= false)
		@DateTimeFormat(pattern = "yyyy-MM-dd")
		private LocalDate dataMorte;

		@Column(nullable=false)
		@DateTimeFormat(pattern = "yyyy-MM-dd")
		private LocalDate dataNascita;
		
		 private String foto;

		
		@ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
		private List<Opera> opere;
		
		
		public Artista() {
			this.opere= new ArrayList<>();
		}
		public Artista(String nome, String cognome, String nazionalita,LocalDate dataNascita, LocalDate dataMorte) {
			this();
			this.nome=nome;
			this.cognome=cognome;
			this.nazionalita=nazionalita;
			this.dataMorte=dataMorte;
			this.dataNascita=dataNascita;
			
		}
	    public Long getId() {
	        return id;
	    }

	    public void setId(Long id) {
	        this.id = id;
	    }

	    public String getNome() {
	        return nome;
	    }

	    public void setNome(String nome) {
	        this.nome = nome;
	    }
	    public String getCognome() {
	        return cognome;
	    }

	    public void setCognome(String cognome) {
	        this.cognome = cognome;
	    }
	    
	    public String getNazionalita() {
	        return nazionalita;
	    }

	    public void setNazionalita(String nazionalita) {
	        this.nazionalita = nazionalita;
	    }
	    public LocalDate getDataNascita() {
			return dataNascita;
		}

		public void setDataNascita(LocalDate dataNascita) {
			this.dataNascita = dataNascita;
		}

		public LocalDate getDataMorte() {
			return dataMorte;
		}

		public void setDataMorte(LocalDate dataMorte) {
			this.dataMorte = dataMorte;
		}
		public List<Opera> getOpere() {
			return opere;
		}

		public void setOpere(List<Opera> opere) {
			this.opere = opere;
		}
		public String getFoto() {
	        return foto;
	    }

	    public void setFoto(String foto) {
	        this.foto = foto;
	    }
		
		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((nome == null) ? 0 : nome.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Artista other = (Artista) obj;
			if (nome == null) {
				if (other.nome != null)
					return false;
			} else if (!nome.equals(other.nome))
				return false;
			return true;

		}
		
		
		public static List<LocalDate> getDatesBetween(LocalDate checkin, LocalDate checkout) { 
	        long numOfDaysBetween = ChronoUnit.DAYS.between(checkin, checkout); 
	        return IntStream.iterate(0, i -> i + 1)
	                        .limit(numOfDaysBetween)
	                        .mapToObj(i -> checkin.plusDays(i))
	                        .collect(Collectors.toList());
	    }

		@Override
		public String toString() {
			return "Artista [id=" + id + ", dataNascita=" + dataNascita + ", dataMorte=" + dataMorte
					+ ", opere=" + opere + ", autore=" + nome + "  ]";
		}
		 
		
}




