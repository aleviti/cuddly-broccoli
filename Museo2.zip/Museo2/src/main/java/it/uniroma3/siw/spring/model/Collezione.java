package it.uniroma3.siw.spring.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name = "collezioni")
public class Collezione {
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(nullable = false ,length=20)
    private String nome;
    @Column(nullable = false,  length=30)
    private String nomeCuratore;
   

    private String foto;
    @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    private List<Opera> opere;
    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    private Curatore curatore;
    
    
    public Collezione() {
    	this.opere=new ArrayList<>();
    }
    
    public Collezione(String nome, String nomeCuratore) {
    	this();
    	
    	this.nome=nome;
    	this.nomeCuratore=nomeCuratore;
    	
    	
    }
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getNomeCuratore() {
        return nomeCuratore;
    }

    public void setNomeCuratore(String nomeCuratore) {
        this.nomeCuratore = nomeCuratore;
    }
   
   

    public List<Opera> getOpera() {
		return opere;
	}

	public void setOpera(List<Opera> opere) {
		this.opere = opere;
	}
	public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((nome == null) ? 0 : nome.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Collezione other = (Collezione) obj;
		if (nome == null) {
			if (other.nome != null)
				return false;
		} else if (!nome.equals(other.nome))
			return false;
		return true;

	}
	
	@Override
	public String toString() {
		return "Collezione [id=" + id + ", nome=" + nome + ", nome=" + nome + "  ]";
	}

	public static void c(Collezione coll) {
		
		
	}

	

	
}
