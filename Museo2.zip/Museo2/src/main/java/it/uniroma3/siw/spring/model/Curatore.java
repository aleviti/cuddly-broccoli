package it.uniroma3.siw.spring.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.OneToMany;

@Entity
public class Curatore {
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(nullable = false ,length=20)
    private String nomeCuratore;
    @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    private List<Collezione> collezioni;
    private String foto;
    public Curatore() {
		this.collezioni= new ArrayList<>();
	}
	public Curatore(String nomeCuratore) {
		this();
		this.nomeCuratore=nomeCuratore;
		
		
		
	}
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNomeCuratore() {
        return nomeCuratore;
    }
    
    public void setNomeCuratore(String nomeCuratore) {
    	this.nomeCuratore=nomeCuratore;
    }
    public List<Collezione> getCollezioni() {
		return collezioni;
	}

	public void setCollezioni(List<Collezione> collezioni) {
		this.collezioni = collezioni;
	}
	
    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((nomeCuratore == null) ? 0 : nomeCuratore.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Curatore other = (Curatore) obj;
		if (nomeCuratore == null) {
			if (other.nomeCuratore != null)
				return false;
		} else if (!nomeCuratore.equals(other.nomeCuratore))
			return false;
		return true;

	}
	
	
	

	@Override
	public String toString() {
		return "Curatore [id=" + id + ",, collezioni=" + collezioni + ", curatore=" + nomeCuratore + "  ]";
	}
	
	
		
	
}
