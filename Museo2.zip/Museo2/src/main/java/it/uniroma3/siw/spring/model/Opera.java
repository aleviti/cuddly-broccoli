package it.uniroma3.siw.spring.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "opere")
public class Opera {
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(nullable = false ,length=20)
    private String titolo;
    @Column(nullable = false,  length=30)
    private String immagine;
    @Column(nullable = false, length= 10)
    private String descrizione;
    
    private String foto;
  
    @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    private List<Autore> autori;
    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    private Artista artista;
    @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    private List<Collezione> collezioni;
    
    public Opera() {
    	this.autori=new ArrayList<>();
    	this.collezioni=new ArrayList<>();
    }
    
    public Opera(String titolo, String immagine, String descrizione) {
    	this();
    	
    	this.titolo=titolo;
    	this.descrizione=descrizione;
    	
    	this.immagine=immagine;
    	
    }
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }
    
   
    public String getImmagine() {
		return immagine;
	}

	public void setImmagine(String immagine) {
		this.immagine = immagine;
	}

	public List<Autore> getAutori() {
		return autori;
	}

	public void setAutori(List<Autore> autori) {
		this.autori = autori;
	}

	public List<Collezione> getCollezioni() {
		return collezioni;
	}

	public void setCollezioni(List<Collezione> collezioni) {
		this.collezioni = collezioni;
	}

	public String getTitolo() {
        return titolo;
    }

    public void setTitolo(String titolo) {
        this.titolo = titolo;
    }

    public List<Autore> getAutore() {
		return autori;
	}

	public void setAutore(List<Autore> autori) {
		this.autori = autori;
	}

    public Artista getArtista() {
		return artista;
	}

	public void setArtista(Artista artista) {
		this.artista = artista;
	}
	 public List<Collezione> getCollezione() {
			return collezioni;
		}

		public void setCollezione(List<Collezione> collezioni) {
			this.collezioni = collezioni;
		}
		
		public String getFoto() {
	        return foto;
	    }

	    public void setFoto(String foto) {
	        this.foto = foto;
	    }
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		
		result = prime * result + ((titolo == null) ? 0 : titolo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Opera other = (Opera) obj;
		
		if (titolo == null) {
			if (other.titolo != null)
				return false;
		} else if (!titolo.equals(other.titolo))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Opera [id=" + id + ", titolo=" + titolo + ", titolo=" + titolo + "]";
	}
    
}


