package it.uniroma3.siw.spring.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import it.uniroma3.siw.spring.model.Autore;

import it.uniroma3.siw.spring.repository.AutoreRepository;


@Service
public class AutoreService {
	@Autowired
	private AutoreRepository  autoreRepository;
	@Transactional
	public Autore inserisci(Autore autore) {
		return autoreRepository.save(autore);
	}

	@Transactional
	public List<Autore> tutti() {
		return (List<Autore>) autoreRepository.findAll();
	}

	@Transactional
	public Autore autorePerId(Long id) {
		Optional<Autore> optional = autoreRepository.findById(id);
		if (optional.isPresent())
			return optional.get();
		else 
			return null;
	}

	@Transactional
	public boolean alreadyExists(Autore autore) {
		List<Autore> autori = this.autoreRepository.findByNome(autore.getNome());
		if (autori.size() > 0)
			return true;
		else 
			return false;
	}

	

	
	}

	
	
	

